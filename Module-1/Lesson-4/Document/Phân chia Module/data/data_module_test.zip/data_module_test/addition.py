def add(a,b):
    c = a+b
    print(c)
    return