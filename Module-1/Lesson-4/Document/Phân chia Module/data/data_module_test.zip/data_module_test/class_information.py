def show_information(name):
    print(f"{name} hoc lop MetaMind")