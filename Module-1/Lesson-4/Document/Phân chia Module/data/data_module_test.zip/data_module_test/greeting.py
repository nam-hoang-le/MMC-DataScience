def hello(name):
    print('Hello, ' + name)